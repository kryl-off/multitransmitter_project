#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QHostAddress>
#include <QDebug>
#include <QNetworkDatagram>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    connect(&udpSocket, SIGNAL(readyRead()), this, SLOT(slotRead()));

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::slotRead()
{
    QByteArray datagram;

    datagram.resize(udpSocket.pendingDatagramSize());

    QHostAddress *address = new QHostAddress("10.10.0.149");

    udpSocket.readDatagram(datagram.data(), datagram.size(), address);

    qDebug() << Q_FUNC_INFO << address->toString() << datagram.size() << datagram.toHex();
}


void MainWindow::on_pushButton_clicked()
{
    qDebug() << udpSocket.bind(QHostAddress::AnyIPv4, 7777);
}

void MainWindow::on_pushButton_2_clicked()
{
    QByteArray data;

    data.append('1');
    udpSocket.writeDatagram(data, QHostAddress::Broadcast, 7777);
}
